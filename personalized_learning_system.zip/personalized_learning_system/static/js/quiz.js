document.addEventListener("DOMContentLoaded", function () {

    const subject = document.getElementById("subject").value;
    const quizBox = document.getElementById("quiz-box");
    const resultBox = document.getElementById("result-box");

    fetch("/static/questions.json")
        .then(res => res.json())
        .then(data => {

            console.log("JSON Loaded:", data);
            console.log("Subject from page:", subject);

            // Directly try to match JSON key
            let subjectKey = null;

            if (data[subject]) subjectKey = subject;
            else if (data[subject.toLowerCase()]) subjectKey = subject.toLowerCase();
            else if (data[subject.charAt(0).toUpperCase() + subject.slice(1)])
                subjectKey = subject.charAt(0).toUpperCase() + subject.slice(1);

            if (!subjectKey) {
                quizBox.innerHTML = `<p style="color:red">
                    Subject "${subject}" not found in questions.json
                </p>`;
                return;
            }

            const questions = data[subjectKey].mcqs;

            let html = "";

            questions.forEach((q, index) => {

                html += `<div class="question-block">`;
                html += `<p><b>Q${index + 1}. ${q.question}</b></p>`;

                q.options.forEach(opt => {
                    html += `
                        <label>
                            <input type="radio" name="q${index}" value="${opt}">
                            ${opt}
                        </label><br>
                    `;
                });

                html += `</div>`;
            });

            html += `<button onclick="submitQuiz()">Submit Quiz</button>`;

            quizBox.innerHTML = html;
            window.quizData = questions;

        })
        .catch(err => {
            console.error(err);
            quizBox.innerHTML = "<p style='color:red'>Failed to load quiz questions.</p>";
        });

});


function submitQuiz() {

    let score = 0;

    window.quizData.forEach((q, index) => {

        const selected = document.querySelector(`input[name="q${index}"]:checked`);

        if (selected && selected.value === q.answer) {
            score++;
        }

    });

    document.getElementById("result-box").innerHTML =
        `Your Score: ${score} / ${window.quizData.length}`;
}