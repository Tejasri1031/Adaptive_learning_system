document.addEventListener("DOMContentLoaded", function () {

/* ---------- ADD CSS AUTOMATICALLY ---------- */

const style = document.createElement("style");

style.innerHTML = `
#chatbot-btn{
position:fixed;
bottom:25px;
right:25px;
background:#007BFF;
color:white;
width:60px;
height:60px;
border-radius:50%;
display:flex;
align-items:center;
justify-content:center;
font-size:24px;
cursor:pointer;
box-shadow:0 4px 15px rgba(0,0,0,0.3);
z-index:9999;
}

#chatbot-window{
position:fixed;
bottom:100px;
right:25px;
width:320px;
height:400px;
background:white;
border-radius:10px;
box-shadow:0 5px 25px rgba(0,0,0,0.3);
display:none;
flex-direction:column;
overflow:hidden;
z-index:9999;
}

#chat-header{
background:#007BFF;
color:white;
padding:10px;
font-weight:bold;
}

#chat-body{
flex:1;
padding:10px;
overflow-y:auto;
}

#chat-input-area{
display:flex;
border-top:1px solid #ddd;
}

#chat-input{
flex:1;
padding:10px;
border:none;
outline:none;
}

#chat-input-area button{
background:#007BFF;
color:white;
border:none;
padding:10px;
cursor:pointer;
}
`;

document.head.appendChild(style);


/* ---------- CREATE CHATBOT ---------- */

const btn = document.createElement("div");
btn.id = "chatbot-btn";
btn.innerHTML = "💬";

const chat = document.createElement("div");
chat.id = "chatbot-window";

chat.innerHTML = `
<div id="chat-header">
AI Assistant
<span onclick="toggleChat()" style="float:right;cursor:pointer;">✖</span>
</div>

<div id="chat-body"></div>

<div id="chat-input-area">
<input id="chat-input" placeholder="Ask something...">
<button onclick="sendMessage()">Send</button>
</div>
`;

document.body.appendChild(btn);
document.body.appendChild(chat);

btn.onclick = toggleChat;

});


function toggleChat(){

const chat = document.getElementById("chatbot-window");

if(chat.style.display === "flex"){

    /* close chatbot */
    chat.style.display = "none";

    /* clear old messages */
    const chatBody = document.getElementById("chat-body");
    chatBody.innerHTML = "";

}
else{

    /* open chatbot */
    chat.style.display = "flex";

}

}

function sendMessage(){

const input = document.getElementById("chat-input");
const message = input.value.trim();

if(message === "") return;

const chatBody = document.getElementById("chat-body");

/* show user message */

chatBody.innerHTML += `<p><b>You:</b> ${message}</p>`;

input.value="";

/* send message to Flask backend */

fetch("/chatbot", {
method: "POST",
headers: {
"Content-Type": "application/json"
},
body: JSON.stringify({ message: message })
})

.then(response => response.json())

.then(data => {

chatBody.innerHTML += `<p><b>Bot:</b> ${data.reply}</p>`;

chatBody.scrollTop = chatBody.scrollHeight;

})

.catch(error => {

chatBody.innerHTML += `<p><b>Bot:</b> Error contacting server.</p>`;

});

}