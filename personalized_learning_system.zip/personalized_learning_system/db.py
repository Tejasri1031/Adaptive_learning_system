from pymongo import MongoClient
from config import MONGO_URI

def get_db():
    client = MongoClient(MONGO_URI)
    db = client.get_default_database()  # Uses the DB name in the URI
    return db
