# chat_responses.py

def get_response(user_input: str) -> str:

    if not user_input:
        return "Please type something so I can help you 🙂"

    user_input = user_input.lower()
   
    # ---------------------------
# Programming Fundamentals
# ---------------------------

    if "what is data types" in user_input or "data types" in user_input:
        return """Data Types:

    Data types define the type of data a variable can store.

    Examples:
    int → integers
    float → decimal numbers
    str → text
    bool → True or False

    Example:
    ```python
    x = 10
    name = "John"
    price = 10.5
    """
    if "what is syntax" in user_input:
        return """Syntax:

    Syntax is the set of rules that defines how code must be written in a programming language.

    Example:
    if x > 5:
    print("Hello")
    """
    if "use of data types" in user_input:
        return "Data types help the computer understand what type of value a variable holds and how it should be processed."

    if "use of loops" in user_input:
        return "Loops allow a block of code to run repeatedly without writing the same code multiple times."

    if "use of syntax" in user_input:
        return "Syntax ensures that the program follows the correct structure so the interpreter or compiler can understand it."

    if "what is oops" in user_input:
        return """OOPS (Object Oriented Programming):

    OOPS is a programming paradigm based on objects and classes.

    Main concepts:
    • Class
    • Object
    • Inheritance
    • Polymorphism
    """
    if "use of oops" in user_input:
        return "OOPS improves code organization, reusability, scalability, and maintainability."

    if "use of if else" in user_input or "use of if else statements" in user_input:
        return "If-else statements allow programs to make decisions based on conditions."

    # ---------------------------
    # Exception Handling
    # ---------------------------

    if "what is exception handling" in user_input:
        return """Exception Handling:

    Exception handling is used to handle runtime errors without stopping the program.

    Example:
    try:
    x = 10/0
    except ZeroDivisionError:
    print("Error occurred")
    """
    if "how we handle exception" in user_input:
        return "Exceptions are handled using try, except, finally, and raise blocks."

    if "use of exception handling" in user_input:
        return "Exception handling prevents program crashes and allows errors to be handled gracefully."

    # ---------------------------
    # OOPS Pillars
    # ---------------------------

    if "4 pillars" in user_input or "four pillars" in user_input:
        return """Four Pillars of OOPS:

    Encapsulation

    Inheritance

    Polymorphism

    Abstraction
    """
    # ---------------------------
    # Loops
    # ---------------------------

    if "what is for loop" in user_input:
        return """For Loop:

    A for loop is used to iterate over a sequence.

    Example:

    for i in range(5):
        print(i)

    """

    if "what is while loop" in user_input:
        return """While Loop:

    A while loop runs as long as the condition is true.
    Example:

    i = 0
    while i < 5:
        print(i)
        i += 1

    """

    if "nested if" in user_input:
        return "Nested if means an if statement inside another if statement."

    if "nested loops" in user_input:
        return """Nested Loops:

    A loop inside another loop.

    Example:

    for i in range(3):
        for j in range(3):
            print(i, j)

    """
#     ---------------------------
#       Programming Languages
#    ---------------------------

    if "why python" in user_input:
        return "Python is easy to learn, readable, and widely used in AI, data science, automation, and web development."

    if "why java" in user_input:
        return "Java is platform independent and widely used for enterprise applications and Android development."

    if "why c++" in user_input:
        return "C++ is powerful for system programming, game development, and high-performance applications."

    if "why c" in user_input:
        return "C is fast and efficient and widely used for system programming and embedded systems."
    # ---------------------------
    # Python Data Structures
    # ---------------------------

    if "list vs tuple" in user_input:
        return """List vs Tuple

    List:
    • Mutable
    • Uses []
    • Can change elements

    Tuple:
    • Immutable
    • Uses ()
    • Cannot change elements
    """

    if "set vs dictionary" in user_input:
        return """Set vs Dictionary

    Set:
    • Stores unique values
    • No key-value pair

    Dictionary:
    • Stores data as key-value pairs
    """
    # ---------------------------
    # Python Features
    # ---------------------------

    if "file handling" in user_input:
        return """File Handling:

    Used to read or write files.

    Example:

    file = open("data.txt","r")
    print(file.read())
    file.close()

    """

    if "python libraries" in user_input:
        return "Python libraries are pre-written modules such as NumPy, Pandas, Matplotlib, TensorFlow, and Scikit-learn."

    if "list comprehensions" in user_input:
        return """List Comprehension:

    A short way to create lists.

    Example:

    numbers = [x for x in range(10)]

    """

    if "loops vs conditional" in user_input:
        return "Loops repeat code multiple times, while conditional statements (if, else) make decisions."
    # ---------------------------
    # Basic Programs
    # ---------------------------

    if "what is factorial" in user_input:
        return "Factorial is the product of all positive integers up to a number. Example: 5! = 120."

    if "palindrome" in user_input:
        return "A palindrome is a word or number that reads the same forward and backward."

    if "fibonacci" in user_input:
        return "Fibonacci series is a sequence where each number is the sum of the previous two numbers."

    # ---------------------------
    # List Methods
    # ---------------------------

    if "append" in user_input:
        return "append() adds a single element to the end of a list."

    if "extend" in user_input:
        return "extend() adds multiple elements from another iterable to the list."

    if "add" in user_input:
        return "add() adds an element to a set."

    if "remove" in user_input:
        return "remove() deletes a specific element from a list."

    # ---------------------------
    # Strings
    # ---------------------------

    if "string vs character" in user_input:
        return "A character represents a single symbol, while a string represents a sequence of characters."

    if "string immutable" in user_input:
        return "Strings are immutable in Python, meaning they cannot be changed after creation."

    if "string methods" in user_input:
        return """Common String Methods:

    upper()
    lower()
    replace()
    split()
    strip()
    """

    # ---------------------------
    # Typing
    # ---------------------------

    if "static typing" in user_input:
        return "Static typing means variable types are defined at compile time. Example: Java, C++."

    if "dynamic typing" in user_input:
        return "Dynamic typing means variable types are determined at runtime. Example: Python."

    # ---------------------------
    # Control Statements
    # ---------------------------

    if "break" in user_input:
        return "break statement immediately exits the loop."

    if "continue" in user_input:
        return "continue skips the current iteration and moves to the next iteration."

    if "pass statement" in user_input:
        return "pass is a placeholder statement that does nothing but prevents syntax errors."

    # ---------------------------
    # Algorithms
    # ---------------------------

    if "anagram" in user_input:
        return "An anagram is a word formed by rearranging letters of another word. Example: listen → silent."

    if "comments" in user_input:
        return """Comments:

    Comments explain the code and are ignored by the interpreter.

    Example:

    # This is a comment

    """
    # ---------------------------
# Python Coding Examples
# ---------------------------

    if "reverse a string" in user_input:
        return """Reverse a String

    Question:
    Write code to reverse a given string.

    Python Code:
    ```python
    def reverse_string(s):
        return s[::-1]

    print(reverse_string("hello"))  # Output: olleh
    """
    if "palindrome" in user_input and "string" in user_input:
        return """Check Palindrome

    Question:
    Check if a string is a palindrome (ignoring spaces and case).

    Python Code:

    def is_palindrome(s):
        s = s.replace(" ", "").lower()
        return s == s[::-1]

    print(is_palindrome("Race car"))  # Output: True

    """

    if "duplicate elements in list" in user_input:
        return """Find Duplicate Elements in a List

    Question:
    Print all duplicate elements from a list.

    Python Code:

    from collections import Counter

    def find_duplicates(lst):
        count = Counter(lst)
        return [item for item, freq in count.items() if freq > 1]

    print(find_duplicates([1, 2, 3, 2, 4, 1]))  # Output: [1, 2]

    """

    if "count vowels" in user_input:
        return """Count Vowels in a String

    Question:
    Count the number of vowels in a string.

    Python Code:

    def count_vowels(s):
        return sum(1 for char in s.lower() if char in "aeiou")

    print(count_vowels("Python is fun"))  # Output: 4

    """

    if "factorial using recursion" in user_input or "recursive factorial" in user_input:
        return """Factorial Using Recursion

    Question:
    Write a recursive function to find the factorial of a number.

    Python Code:

    def factorial(n):
        if n == 0 or n == 1:
            return 1
        return n * factorial(n - 1)

    print(factorial(5))  # Output: 120

    """

    # Greetings
    if any(word in user_input for word in ["hello","hi","hai"]):
        return "Hello 👋! I'm your AI Learning Buddy. You can ask me about Python, Java, C, or C++."
    # ---------------------------
    # General greetings & basics
    # ---------------------------
    if "hello" in user_input or "hi" in user_input or "hai" in user_input:
        return "Hello 👋! I'm your AI Learning Buddy. You can ask me about Python, Java, C, or C++."
    if "how are you" in user_input:
        return "I'm just code, but I'm doing great 😃. How can I help you today?"
    if "thank you" in user_input or "thanks" in user_input:
        return "You're welcome! 🌟 Keep learning and coding 🚀"
    if "who are you" in user_input:
        return "I'm your AI Learning Buddy 🤖, here to help you with programming concepts."
    if "what is programming" in user_input:
        return "Programming is the process of writing instructions for a computer to perform specific tasks."
    if "what is compiler" in user_input:
        return "A compiler translates high-level code into machine code so the computer can execute it."
    if "what is interpreter" in user_input:
        return "An interpreter executes code line by line instead of converting it to machine code first."
    if "what is algorithm" in user_input:
        return "An algorithm is a step-by-step procedure to solve a problem."
    if "what is data structure" in user_input:
        return "Data structures are ways of organizing data (like arrays, linked lists, stacks, queues, trees, graphs)."
    if "what is variable" in user_input:
        return "A variable is a named storage in memory that holds a value."
    if "what is constant" in user_input:
        return "A constant is a value that does not change during program execution."
    if "difference between array and linked list" in user_input:
        return "Array: fixed size, stored in contiguous memory. Linked List: dynamic size, elements linked with pointers."
    if "difference between stack and queue" in user_input:
        return "Stack: LIFO (Last In First Out). Queue: FIFO (First In First Out)."
        # ---------------------------
    # General Programming Concepts
    # ---------------------------

    if "what is loop" in user_input:
        return "A loop is used to execute a block of code repeatedly until a condition is met. Common loops are for loop and while loop."

    if "types of loops" in user_input:
        return "Common loop types: for loop, while loop, do-while loop."

    if "what is array" in user_input:
        return "An array is a collection of elements of the same data type stored in contiguous memory locations."

    if "what is function" in user_input:
        return "A function is a reusable block of code that performs a specific task."

    if "what is recursion" in user_input:
        return "Recursion is a technique where a function calls itself to solve a problem."

    if "what is class" in user_input:
        return "A class is a blueprint used to create objects in object-oriented programming."

    if "what is object" in user_input:
        return "An object is an instance of a class that contains data and methods."

    if "what is inheritance" in user_input:
        return "Inheritance allows one class to acquire the properties and methods of another class."

    if "what is polymorphism" in user_input:
        return "Polymorphism means the same function or method behaves differently in different situations."

    if "what is encapsulation" in user_input:
        return "Encapsulation is the process of hiding internal data and allowing access only through methods."

    if "what is abstraction" in user_input:
        return "Abstraction hides complex implementation details and shows only essential features."

    if "what is data structure" in user_input:
        return "A data structure is a way of organizing and storing data efficiently."

    if "what is algorithm" in user_input:
        return "An algorithm is a step-by-step procedure used to solve a problem."

    if "what is stack" in user_input:
        return "A stack is a data structure that follows LIFO (Last In First Out)."

    if "what is queue" in user_input:
        return "A queue is a data structure that follows FIFO (First In First Out)."

    if "what is linked list" in user_input:
        return "A linked list is a linear data structure where elements are connected using pointers."

    if "what is pointer" in user_input:
        return "A pointer is a variable that stores the memory address of another variable."

    if "what is variable" in user_input:
        return "A variable is a named memory location used to store data."

    if "what is constant" in user_input:
        return "A constant is a value that cannot be changed during program execution."

    if "what is compiler" in user_input:
        return "A compiler converts high-level programming code into machine code."

    if "what is interpreter" in user_input:
        return "An interpreter executes code line by line without converting it completely to machine code."

    if "what is syntax" in user_input:
        return "Syntax refers to the rules that define the structure of a programming language."

    if "what is debugging" in user_input:
        return "Debugging is the process of identifying and fixing errors in a program."

    if "what is runtime error" in user_input:
        return "Runtime errors occur while the program is running."

    if "what is logical error" in user_input:
        return "Logical errors occur when the program runs but produces incorrect results."
        # ---------------------------
    # Common Question Variations
    # ---------------------------

    if "loop" in user_input and ("what" in user_input or "define" in user_input or "explain" in user_input or "meaning" in user_input):
        return "A loop is used to repeat a block of code multiple times until a condition becomes false."

    if "array" in user_input and ("what" in user_input or "define" in user_input or "explain" in user_input):
        return "An array is a collection of elements of the same type stored in contiguous memory."

    if "function" in user_input and ("what" in user_input or "define" in user_input or "explain" in user_input):
        return "A function is a reusable block of code that performs a specific task."

    if "class" in user_input and ("what" in user_input or "define" in user_input or "explain" in user_input):
        return "A class is a blueprint used to create objects in object-oriented programming."

    if "object" in user_input and ("what" in user_input or "define" in user_input or "explain" in user_input):
        return "An object is an instance of a class that contains data and methods."

    if "inheritance" in user_input and ("what" in user_input or "define" in user_input or "explain" in user_input):
        return "Inheritance allows one class to acquire properties and methods of another class."

    if "polymorphism" in user_input and ("what" in user_input or "define" in user_input or "explain" in user_input):
        return "Polymorphism allows methods to perform different tasks based on the object calling them."

    if "encapsulation" in user_input and ("what" in user_input or "define" in user_input or "explain" in user_input):
        return "Encapsulation hides internal data and allows access through methods."

    if "abstraction" in user_input and ("what" in user_input or "define" in user_input or "explain" in user_input):
        return "Abstraction hides implementation details and shows only essential features."

    if "recursion" in user_input and ("what" in user_input or "define" in user_input or "explain" in user_input):
        return "Recursion is when a function calls itself to solve smaller parts of a problem."

    if "stack" in user_input and ("what" in user_input or "define" in user_input or "explain" in user_input):
        return "A stack is a data structure that follows LIFO (Last In First Out)."

    if "queue" in user_input and ("what" in user_input or "define" in user_input or "explain" in user_input):
        return "A queue is a data structure that follows FIFO (First In First Out)."

    if "linked list" in user_input and ("what" in user_input or "define" in user_input or "explain" in user_input):
        return "A linked list is a collection of nodes connected through pointers."

    if "algorithm" in user_input and ("what" in user_input or "define" in user_input or "explain" in user_input):
        return "An algorithm is a step-by-step procedure to solve a problem."

    if "data structure" in user_input and ("what" in user_input or "define" in user_input or "explain" in user_input):
        return "A data structure organizes data efficiently for processing."

    if "compiler" in user_input and ("what" in user_input or "define" in user_input):
        return "A compiler converts high-level programming code into machine code."

    if "interpreter" in user_input and ("what" in user_input or "define" in user_input):
        return "An interpreter executes code line by line."

    if "variable" in user_input and ("what" in user_input or "define" in user_input):
        return "A variable is a named memory location used to store data."

    if "constant" in user_input and ("what" in user_input or "define" in user_input):
        return "A constant is a value that cannot change during program execution."
        # ---------------------------
    # Python
    # ---------------------------
    if "what is python" in user_input:
        return "Python is a high-level, interpreted language known for its simplicity and readability."
    if "python data types" in user_input:
        return "Common Python data types: int, float, str, list, tuple, set, dict, bool."
    if "python operators" in user_input:
        return "Python operators: Arithmetic (+,-,*,/), Comparison (==, !=, >,<), Logical (and, or, not), Membership (in, not in)."
    if "python loops" in user_input:
        return "Python supports for loop and while loop. Example: \nfor i in range(5): print(i)"
    if "python function" in user_input:
        return "Functions in Python are defined with `def`. Example:\n```python\ndef greet(name):\n    return f'Hello {name}'\n```"
    if "python list vs tuple" in user_input:
        return "List is mutable (can be changed), Tuple is immutable (cannot be changed)."
    if "python dictionary" in user_input:
        return "Dictionary stores key-value pairs. Example: `student = {'name':'Teju', 'age':20}`"
    if "python set" in user_input:
        return "A set is an unordered collection of unique elements. Example: `{1,2,3}`"
    if "python class" in user_input:
        return "Classes in Python define objects. Example:\n```python\nclass Student:\n    def __init__(self,name):\n        self.name=name\n```"
    if "python exception" in user_input:
        return "Python uses try-except blocks. Example:\n```python\ntry:\n    x=10/0\nexcept ZeroDivisionError:\n    print('Error!')\n```"
    if "python module" in user_input:
        return "A module is a file containing Python code. Example: math, random, os."
    if "python package" in user_input:
        return "A package is a collection of modules, organized in directories with __init__.py file."
 

    if "python version" in user_input:
        return "You can check Python version using: python --version"

    if "python keywords" in user_input:
        return "Python keywords include: if, else, elif, while, for, def, return, class, try, except."

    if "python len function" in user_input:
        return "len() returns the length of an object."

    if "python range function" in user_input:
        return "range() generates a sequence of numbers."

    if "python tuple" in user_input:
        return "Tuple is an ordered, immutable collection."

    if "python list" in user_input:
        return "List is an ordered, mutable collection."

    if "python slicing" in user_input:
        return "Slicing extracts parts of sequences. Example: text[1:4]"

    if "python boolean" in user_input:
        return "Boolean values are True or False."

    if "python type function" in user_input:
        return "type() returns the data type of a variable."

    if "python enumerate" in user_input:
        return "enumerate() returns index and value during loops."

    if "python zip" in user_input:
        return "zip() combines multiple lists."

    if "python map function" in user_input:
        return "map() applies a function to all items in an iterable."

    if "python filter function" in user_input:
        return "filter() filters items based on condition."

    if "python recursion" in user_input:
        return "Recursion is when a function calls itself."

    if "python docstring" in user_input:
        return "Docstrings document functions."

    if "python list comprehension" in user_input:
        return "Short way to create lists."

    if "python set operations" in user_input:
        return "Set supports union, intersection and difference."

    if "python dictionary methods" in user_input:
        return "Common dictionary methods: keys(), values(), items()"

    if "python pop method" in user_input:
        return "pop() removes element from list or dictionary."

    if "python append method" in user_input:
        return "append() adds item to list."

    if "python extend method" in user_input:
        return "extend() adds multiple items to list."

    if "python sort method" in user_input:
        return "sort() sorts list elements."

    if "python reverse method" in user_input:
        return "reverse() reverses list."

    if "python split method" in user_input:
        return "split() divides string into list."

    if "python join method" in user_input:
        return "join() combines list into string."

    if "python strip method" in user_input:
        return "strip() removes whitespace."

    if "python global keyword" in user_input:
        return "global keyword accesses global variables."

    if "python local variable" in user_input:
        return "Local variables exist inside functions."

    if "python modules example" in user_input:
        return "Example modules: math, random, os."

    if "python random module" in user_input:
        return "random module generates random numbers."

    if "python math module" in user_input:
        return "math module provides mathematical functions."

    if "python file read" in user_input:
        return "read() reads file content."

    if "python file write" in user_input:
        return "write() writes content to file."

    if "python try except" in user_input:
        return "try/except handles errors."

    if "python finally block" in user_input:
        return "finally always executes."

    if "python class example" in user_input:
        return "Classes define objects."

    if "python object example" in user_input:
        return "Object is instance of class."

    if "python inheritance example" in user_input:
        return "Inheritance allows reuse of code."

    if "python encapsulation" in user_input:
        return "Encapsulation hides internal data."

    if "python polymorphism example" in user_input:
        return "Polymorphism allows same function name with different behavior."

    if "python decorator" in user_input:
        return "Decorators modify functions."

    if "python generator" in user_input:
        return "Generators yield values one by one."

    if "python yield keyword" in user_input:
        return "yield returns generator values."

    if "python virtual environment" in user_input:
        return "Virtual environments isolate Python dependencies."

    if "python pip" in user_input:
        return "pip installs Python packages."

    if "python pip install" in user_input:
        return "Use pip install package_name."
    if "array vs list" in user_input or "difference between array and list" in user_input:
        return """Difference between Array and List:

    Array
    • Stores same data type
    • Fixed size
    • Faster access

    List
    • Can store different data types
    • Dynamic size
    • More flexible

    Example in Python:

    arr = [1,2,3,4]
    my_list = [1,"hello",3.5]
    """
    if "list in python" in user_input or "python list" in user_input:
        return """Python List:

    A list is a collection that can store multiple values.

    Example:
    ```python
    numbers = [1,2,3,4]
    names = ["ram","sam","tom"]
    Features:
    • Ordered
    • Mutable (can change)
    • Allows duplicates
    """
    if user_input.strip() == "list" or "what is list" in user_input:
        return """List:

    A list is a collection of items stored in a sequence.

    Example in Python:
    ```python
    my_list = [10,20,30]

    Lists allow:
    • Multiple values
    • Different data types
    • Dynamic size
    """
    if "array" in user_input:
        return """Array:

    An array is a collection of elements of the same data type stored in contiguous memory locations.

    Example in C:
    ```c
    int arr[5] = {1,2,3,4,5};

    Features:
    • Same data type
    • Fixed size
    • Fast access
    """
    def get_response(user_input: str) -> str:

        user_input = user_input.lower().strip()
    words = user_input.split()

    # greetings
    if any(word in words for word in ["hi","hello","hai"]):
        return "Hello 👋 I am your AI Tutor. Ask me about Python, Java, C, or C++."

    # knowledge base
    knowledge = {

        "list": {
            "general": """List:

A list is a collection of elements stored in order.

Example:
```python
my_list = [1,2,3]
```""",

            "python": """Python List:

A list stores multiple values.

Example:
```python
numbers = [1,2,3]
names = ["ram","sam"]
Features:
• Ordered
• Mutable
• Allows duplicates"""
},
"array": {
        "general": """Array:
        An array is a collection of elements of the same datatype stored in contiguous memory.

Example in C:

int arr[5] = {1,2,3,4,5};
```""",

            "difference": """Array vs List

Array
• Same datatype
• Fixed size

List
• Different datatypes allowed
• Dynamic size"""
        },

        "loop": {
            "general": """Loop:

A loop repeats a block of code multiple times.

Example Python:

```python
for i in range(5):
    print(i)
```"""
        },

        "function": {
            "general": """Function:

A function is a reusable block of code.

Example:

```python
def add(a,b):
    return a+b
```"""
        }

    }
    
    # detect concept
    for concept in knowledge:

        if concept in words:

            if "python" in words and "python" in knowledge[concept]:
                return knowledge[concept]["python"]

            if "difference" in words or "vs" in words:
                if "difference" in knowledge[concept]:
                    return knowledge[concept]["difference"]

            return knowledge[concept]["general"]

    return "🤔 I understand your question but I am still learning. Try asking about loops, arrays, lists, or functions."
    # ---------------------------
    # Java
    # ---------------------------
    if "what is java" in user_input:
        return "Java is an object-oriented, class-based programming language that runs on the JVM."
    if "java data types" in user_input:
        return "Java has primitive types (int, float, char, boolean, etc.) and reference types (objects, arrays)."
    if "java inheritance" in user_input:
        return "Inheritance allows one class to acquire properties and methods of another. Use `extends` keyword in Java."
    if "java interface" in user_input:
        return "An interface is like a contract in Java. A class can implement an interface and must define its methods."
    if "java exception" in user_input:
        return "Exception handling in Java uses try, catch, finally, throw, and throws."
    if "java constructor" in user_input:
        return "Constructors initialize objects in Java. They have the same name as the class."
    if "java polymorphism" in user_input:
        return "Java polymorphism: Compile-time (method overloading), Run-time (method overriding)."
    if "what is jvm" in user_input:
        return "JVM (Java Virtual Machine) runs compiled Java bytecode and makes Java platform-independent."
    if "what is garbage collection in java" in user_input:
        return "Garbage collection in Java automatically removes unused objects to free memory."
# ---------------------------
# Java Fundamentals
# ---------------------------

    if "java main method" in user_input:
        return "The main() method is the entry point of a Java program."

    if "java class" in user_input:
        return "A class is a blueprint for objects."

    if "java object" in user_input:
        return "An object is an instance of a class."

    if "java variables" in user_input:
        return "Java variables store data values."

    if "java static keyword" in user_input:
        return "Static means shared across all objects."

    if "java final keyword" in user_input:
        return "final means value cannot be changed."

    if "java string class" in user_input:
        return "String represents text."

    if "java array" in user_input:
        return "Array stores multiple values of same type."

    if "java loop types" in user_input:
        return "Loops include for, while, do-while."

    if "java break statement" in user_input:
        return "break exits loop."

    if "java continue statement" in user_input:
        return "continue skips iteration."

    if "java scanner class" in user_input:
        return "Scanner reads input from user."

    if "java package" in user_input:
        return "Package groups related classes."

    if "java abstract class" in user_input:
        return "Abstract class cannot be instantiated."

    if "java method overloading" in user_input:
        return "Same method name with different parameters."

    if "java method overriding" in user_input:
        return "Child class redefines parent method."

    # ---------------------------
    # C
    # ---------------------------
    if "what is c" in user_input:
        return "C is a procedural programming language, often called the mother of modern programming."
    if "c data types" in user_input:
        return "C data types: int, float, double, char, void, and derived types like arrays, pointers, structs."
    if "c pointers" in user_input:
        return "Pointers in C are variables that store memory addresses. Example: `int *ptr;`"
    if "c arrays" in user_input:
        return "An array is a collection of elements of same type stored in contiguous memory."
    if "c structures" in user_input:
        return "Structures in C allow grouping different data types. Example: `struct Student { int id; char name[20]; };`"
    if "c union" in user_input:
        return "Union in C stores different data types in the same memory location."
    if "c storage classes" in user_input:
        return "Storage classes in C: auto, static, extern, register."
    if "malloc" in user_input or "calloc" in user_input:
        return "malloc and calloc are used for dynamic memory allocation in C. Don't forget to free() memory!"
    if "difference between malloc and calloc" in user_input:
        return "malloc allocates uninitialized memory, calloc allocates and initializes memory with 0."
    # ---------------------------
# C Fundamentals
# ---------------------------

    if "c syntax" in user_input:
        return "C program contains functions, variables and statements."

    if "c main function" in user_input:
        return "main() is the entry point of C program."

    if "c printf" in user_input:
        return "printf() prints output."

    if "c scanf" in user_input:
        return "scanf() reads input."

    if "c header files" in user_input:
        return "Header files contain function declarations."

    if "c loops" in user_input:
        return "C loops: for, while, do-while."

    if "c break" in user_input:
        return "break exits loop."

    if "c continue" in user_input:
        return "continue skips iteration."

    if "c function" in user_input:
        return "Functions perform reusable tasks."

    if "c recursion" in user_input:
        return "Function calling itself."

    if "c memory allocation" in user_input:
        return "Dynamic allocation uses malloc, calloc."

    if "c free function" in user_input:
        return "free() releases allocated memory."

    # ---------------------------
    # C++
    # ---------------------------
    if "what is c++" in user_input:
        return "C++ is an extension of C with Object-Oriented Programming features like classes, objects, and inheritance."
    if "c++ class" in user_input:
        return "A class in C++ is a user-defined type that has attributes (variables) and methods (functions)."
    if "c++ object" in user_input:
        return "An object is an instance of a class in C++."
    if "c++ constructor" in user_input:
        return "Constructors are special methods in C++ used to initialize objects."
    if "c++ destructor" in user_input:
        return "Destructor is a special method in C++ used to clean up when an object is destroyed."
    if "c++ inheritance" in user_input:
        return "C++ supports single, multiple, multilevel, hierarchical, and hybrid inheritance."
    if "c++ polymorphism" in user_input:
        return "Polymorphism in C++ allows functions or operators to behave differently. Compile-time: overloading. Run-time: overriding with virtual functions."
    if "c++ operator overloading" in user_input:
        return "Operator overloading allows redefining operators for user-defined types."
    if "c++ templates" in user_input:
        return "Templates allow generic programming. Example: `template <class T> T add(T a, T b) { return a+b; }`"
    if "c++ stl" in user_input:
        return "STL (Standard Template Library) provides ready-made classes: vector, map, set, queue, stack."
    # ---------------------------
# C++ Fundamentals
# ---------------------------

    if "c++ namespace" in user_input:
        return "namespace avoids name conflicts."

    if "c++ cout" in user_input:
        return "cout prints output."

    if "c++ cin" in user_input:
        return "cin reads input."

    if "c++ reference" in user_input:
        return "Reference is alias for variable."

    if "c++ vector" in user_input:
        return "vector is dynamic array."

    if "c++ map" in user_input:
        return "map stores key value pairs."

    if "c++ set" in user_input:
        return "set stores unique values."

    if "c++ friend function" in user_input:
        return "friend function accesses private data."

    if "c++ virtual function" in user_input:
        return "Virtual functions support runtime polymorphism."

    if "c++ encapsulation" in user_input:
        return "Encapsulation hides internal data."

    if "c++ abstraction" in user_input:
        return "Abstraction hides implementation details."

    if "c++ inheritance types" in user_input:
        return "Types include single, multiple, multilevel."

    if "c++ constructor types" in user_input:
        return "Constructors include default, parameterized."

    if "c++ destructor use" in user_input:
        return "Destructor releases memory."

    if "c++ exception handling" in user_input:
        return "Handled using try, catch."

# chat_responses.py

    # ---------------------------
    # Basic Programs
    # ---------------------------
    if "factorial" in user_input:
        return """Factorial in Python:
```python
def factorial(n):
    return 1 if n==0 else n*factorial(n-1)

print(factorial(5))  # 120
```"""

    if "fibonacci" in user_input:
        return """Fibonacci Series in Python:
```python
n = 10
a, b = 0, 1
for _ in range(n):
    print(a, end=" ")
    a, b = b, a+b
```"""

    if "palindrome" in user_input:
        return """Palindrome Check in Python:
```python
s = "madam"
if s == s[::-1]:
    print("Palindrome")
else:
    print("Not Palindrome")
```"""

    if "prime" in user_input:
        return """Prime Number Check:
```python
n = 29
for i in range(2, int(n**0.5)+1):
    if n % i == 0:
        print("Not Prime")
        break
else:
    print("Prime")
```"""

    if "string reverse" in user_input:
        return """Reverse String:
```python
s = "hello"
print(s[::-1])  # olleh
```"""

    if "swapping numbers" in user_input:
        return """Swapping Numbers:
```python
a, b = 10, 20
a, b = b, a
print(a, b)  # 20 10
```"""

    if "sorting" in user_input:
        return """Sorting List:
```python
arr = [5,3,8,1,2]
print(sorted(arr))
```"""

    if "checking even or odd" in user_input:
        return """Even/Odd:
```python
n = 7
print("Even" if n%2==0 else "Odd")
```"""

    if "reverse of array" in user_input:
        return """Reverse Array:
```python
arr = [1,2,3,4,5]
print(arr[::-1])
```"""

    if "presenting how many even or odd" in user_input:
        return """Count Even/Odd:
```python
arr = [1,2,3,4,5,6,7,8]
even = sum(1 for x in arr if x%2==0)
odd = len(arr)-even
print("Even:", even, "Odd:", odd)
```"""

    if "string vowels" in user_input or "consonants" in user_input:
        return """Vowels & Consonants Count:
```python
s = "hello world"
vowels = "aeiou"
v = sum(1 for ch in s if ch.lower() in vowels)
c = sum(1 for ch in s if ch.isalpha() and ch.lower() not in vowels)
print("Vowels:", v, "Consonants:", c, "Total:", len(s))
```"""

    if "printing 1 to 5" in user_input:
        return """Print 1 to 5:
```python
for i in range(1,6):
    print(i)
```"""

    if "printing 100" in user_input:
        return """Print 1 to 100:
```python
for i in range(1,101):
    print(i, end=" ")
```"""

    if "only even printing" in user_input:
        return """Print Even Numbers:
```python
for i in range(2,101,2):
    print(i, end=" ")
```"""

    if "odd printing" in user_input:
        return """Print Odd Numbers:
```python
for i in range(1,101,2):
    print(i, end=" ")
```"""

    # ---------------------------
    # Patterns
    # ---------------------------
    if "pattern" in user_input:
        return """Star Patterns:
```python
# Right Triangle
for i in range(1,6):
    print("*"*i)

# Pyramid
n=5
for i in range(1,n+1):
    print(" "*(n-i) + "*"*(2*i-1))

# Diamond
n=5
for i in range(1,n+1):
    print(" "*(n-i)+"*"*(2*i-1))
for i in range(n-1,0,-1):
    print(" "*(n-i)+"*"*(2*i-1))
```"""

    # ---------------------------
    # Control Statements
    # ---------------------------
    if "if code" in user_input:
        return """Example of if/else:
```python
x = 10
if x>0:
    print("Positive")
else:
    print("Negative")
```"""

    if "for loop" in user_input:
        return """Example of for loop:
```python
for i in range(5):
    print(i)
```"""

    if "nested loop" in user_input:
        return """Nested Loops:
```python
for i in range(3):
    for j in range(3):
        print(i,j)
```"""

    # ---------------------------
    # Calculator
    # ---------------------------
    if "calculator" in user_input:
        return """Simple Calculator:
```python
a = 10; b = 5
print("Add:", a+b)
print("Sub:", a-b)
print("Mul:", a*b)
print("Div:", a/b)
```"""

    # ---------------------------
    # Mini Project - Attendance
    # ---------------------------
    if "attendance" in user_input:
        return """Simple Attendance Project:
```python
students = ["Alice","Bob","Charlie"]
attendance = {}
for s in students:
    status = input(f"Is {s} present? (y/n): ")
    attendance[s] = "Present" if status.lower()=="y" else "Absent"

print("Attendance Record:", attendance)
```"""

    # ---------------------------
    # OOPs Concepts
    # ---------------------------
    if "oops" in user_input or "class" in user_input:
        return """OOP Example:
```python
class Student:
    def __init__(self,name,age):
        self.name=name
        self.age=age
    def display(self):
        print(f"Name: {self.name}, Age: {self.age}")

s1 = Student("John",21)
s1.display()
```"""

    # ---------------------------
    # Comments
    # ---------------------------
    if "comments" in user_input:
        return """Comments in Python:
```python
# Single line comment
'''
Multi-line
comment
'''
```"""

    # ---------------------------
    # Methods & Operators
    # ---------------------------
    if "methods" in user_input or "operators" in user_input:
        return """Methods & Operators:
```python
# Methods
s = "hello"
print(s.upper())
print(s.replace("h","y"))

# Operators
a, b = 10, 3
print(a+b, a-b, a*b, a/b, a%b, a**b)
```"""


    # ======================
    # JAVA CODING EXAMPLES
    # ======================

    if "java factorial" in user_input:
        return """```java
public class Factorial {
    public static void main(String[] args) {
        int n = 5, fact = 1;
        for (int i = 1; i <= n; i++) {
            fact *= i;
        }
        System.out.println("Factorial: " + fact);
    }
}
```"""

    if "java fibonacci" in user_input:
        return """```java
public class Fibonacci {
    public static void main(String[] args) {
        int n = 10, a = 0, b = 1;
        System.out.print("Fibonacci: " + a + " " + b);
        for (int i = 2; i < n; i++) {
            int c = a + b;
            System.out.print(" " + c);
            a = b;
            b = c;
        }
    }
}
```"""

    if "java palindrome" in user_input:
        return """```java
public class Palindrome {
    public static void main(String[] args) {
        String str = "madam", rev = "";
        for (int i = str.length() - 1; i >= 0; i--)
            rev += str.charAt(i);
        if (str.equals(rev))
            System.out.println("Palindrome");
        else
            System.out.println("Not Palindrome");
    }
}
```"""

    if "java prime" in user_input:
        return """```java
public class Prime {
    public static void main(String[] args) {
        int num = 29, flag = 0;
        for (int i = 2; i <= num / 2; i++) {
            if (num % i == 0) { flag = 1; break; }
        }
        if (flag == 0)
            System.out.println("Prime Number");
        else
            System.out.println("Not Prime");
    }
}
```"""

    if "java string reverse" in user_input:
        return """```java
public class StringReverse {
    public static void main(String[] args) {
        String str = "hello";
        StringBuffer sb = new StringBuffer(str);
        System.out.println(sb.reverse());
    }
}
```"""

    if "java swap" in user_input:
        return """```java
public class Swap {
    public static void main(String[] args) {
        int a = 5, b = 10;
        int temp = a;
        a = b;
        b = temp;
        System.out.println("a=" + a + " b=" + b);
    }
}
```"""

    if "java sort" in user_input:
        return """```java
import java.util.Arrays;
public class Sort {
    public static void main(String[] args) {
        int arr[] = {5, 2, 8, 1};
        Arrays.sort(arr);
        System.out.println(Arrays.toString(arr));
    }
}
```"""

    if "java even or odd" in user_input:
        return """```java
public class EvenOdd {
    public static void main(String[] args) {
        int num = 7;
        if (num % 2 == 0)
            System.out.println("Even");
        else
            System.out.println("Odd");
    }
}
```"""

    if "java reverse array" in user_input:
        return """```java
import java.util.Arrays;
public class ReverseArray {
    public static void main(String[] args) {
        int arr[] = {1, 2, 3, 4};
        for (int i = arr.length - 1; i >= 0; i--)
            System.out.print(arr[i] + " ");
    }
}
```"""

    if "java count even odd between" in user_input:
        return """```java
public class CountEvenOdd {
    public static void main(String[] args) {
        int even = 0, odd = 0;
        for (int i = 1; i <= 10; i++) {
            if (i % 2 == 0) even++; else odd++;
        }
        System.out.println("Even=" + even + " Odd=" + odd);
    }
}
```"""

    if "java vowels consonants" in user_input:
        return """```java
public class VowelsConsonants {
    public static void main(String[] args) {
        String str = "hello world";
        int v=0,c=0;
        str = str.toLowerCase();
        for (char ch : str.toCharArray()) {
            if ("aeiou".indexOf(ch) != -1) v++;
            else if (ch >= 'a' && ch <= 'z') c++;
        }
        System.out.println("Vowels=" + v + " Consonants=" + c);
    }
}
```"""

    if "java print numbers" in user_input:
        return """```java
public class PrintNumbers {
    public static void main(String[] args) {
        for (int i = 1; i <= 5; i++) System.out.println(i);
        for (int i = 1; i <= 100; i++) System.out.print(i + " ");
        System.out.println("\\nEven numbers:");
        for (int i = 2; i <= 100; i+=2) System.out.print(i + " ");
        System.out.println("\\nOdd numbers:");
        for (int i = 1; i <= 100; i+=2) System.out.print(i + " ");
    }
}
```"""

    if "java pattern" in user_input:
        return """```java
public class Pattern {
    public static void main(String[] args) {
        for (int i = 1; i <= 5; i++) {
            for (int j = 1; j <= i; j++)
                System.out.print("* ");
            System.out.println();
        }
    }
}
```"""

    if "java if" in user_input:
        return """```java
public class IfExample {
    public static void main(String[] args) {
        int age = 18;
        if (age >= 18) System.out.println("Eligible to vote");
        else System.out.println("Not eligible");
    }
}
```"""

    if "java for loop" in user_input:
        return """```java
public class ForLoop {
    public static void main(String[] args) {
        for (int i = 1; i <= 5; i++)
            System.out.println(i);
    }
}
```"""

    if "java nested loop" in user_input:
        return """```java
public class NestedLoop {
    public static void main(String[] args) {
        for (int i = 1; i <= 3; i++) {
            for (int j = 1; j <= 3; j++) {
                System.out.print("(" + i + "," + j + ") ");
            }
            System.out.println();
        }
    }
}
```"""

    if "java calculator" in user_input:
        return """```java
import java.util.Scanner;
public class Calculator {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a: "); int a = sc.nextInt();
        System.out.print("Enter b: "); int b = sc.nextInt();
        System.out.println("Sum=" + (a+b));
        System.out.println("Diff=" + (a-b));
        System.out.println("Mul=" + (a*b));
        System.out.println("Div=" + (a/b));
    }
}
```"""

    if "java attendance" in user_input:
        return """```java
import java.util.*;
public class Attendance {
    public static void main(String[] args) {
        HashMap<String, Boolean> record = new HashMap<>();
        record.put("John", true);
        record.put("Alice", false);
        record.put("Bob", true);
        for (String name : record.keySet()) {
            System.out.println(name + ": " + (record.get(name) ? "Present" : "Absent"));
        }
    }
}
```"""

    if "java oops" in user_input:
        return """```java
class Student {
    String name; int age;
    Student(String n, int a) { name=n; age=a; }
    void display() { System.out.println(name + " " + age); }
}
public class OopsDemo {
    public static void main(String[] args) {
        Student s1 = new Student("Alice", 20);
        s1.display();
    }
}
```"""

    if "java comments" in user_input:
        return """```java
public class Comments {
    public static void main(String[] args) {
        // This is a single-line comment
        /* This is a
           multi-line comment */
        System.out.println("Hello with comments!");
    }
}
```"""

    if "java methods operators" in user_input:
        return """```java
public class MethodsOperators {
    static int add(int a, int b) { return a+b; }
    public static void main(String[] args) {
        int sum = add(5, 3);
        int mul = 5 * 3;
        System.out.println("Sum=" + sum);
        System.out.println("Mul=" + mul);
    }
}
```"""


    # ---- C PROGRAM CODES ----
    if "c factorial" in user_input:
        return """```c
#include <stdio.h>
int main() {
    int n, fact=1;
    printf("Enter a number: ");
    scanf("%d", &n);
    for(int i=1; i<=n; i++) {
        fact *= i;
    }
    printf("Factorial = %d", fact);
    return 0;
}
```"""

    if "c fibonacci" in user_input:
        return """```c
#include <stdio.h>
int main() {
    int n, a=0, b=1, c;
    printf("Enter terms: ");
    scanf("%d", &n);
    for(int i=0; i<n; i++) {
        printf("%d ", a);
        c = a + b;
        a = b;
        b = c;
    }
    return 0;
}
```"""

    if "c palindrome" in user_input:
        return """```c
#include <stdio.h>
int main() {
    int n, rev=0, rem, temp;
    printf("Enter number: ");
    scanf("%d", &n);
    temp = n;
    while(n>0) {
        rem = n%10;
        rev = rev*10 + rem;
        n /= 10;
    }
    if(temp == rev) printf("Palindrome");
    else printf("Not Palindrome");
    return 0;
}
```"""

    if "c prime" in user_input:
        return """```c
#include <stdio.h>
int main() {
    int n, flag=0;
    printf("Enter number: ");
    scanf("%d", &n);
    for(int i=2;i<=n/2;i++) {
        if(n%i==0) { flag=1; break; }
    }
    if(flag==0 && n>1) printf("Prime");
    else printf("Not Prime");
    return 0;
}
```"""

    if "c string reverse" in user_input:
        return """```c
#include <stdio.h>
#include <string.h>
int main() {
    char str[100];
    printf("Enter string: ");
    gets(str);
    strrev(str);
    printf("Reversed = %s", str);
    return 0;
}
```"""

    if "c swap" in user_input:
        return """```c
#include <stdio.h>
int main() {
    int a=5, b=10, temp;
    temp=a; a=b; b=temp;
    printf("a=%d b=%d", a, b);
    return 0;
}
```"""

    if "c sort" in user_input:
        return """```c
#include <stdio.h>
int main() {
    int arr[5] = {5,2,8,1,3}, i, j, temp;
    for(i=0;i<5;i++) {
        for(j=i+1;j<5;j++) {
            if(arr[i]>arr[j]) {
                temp=arr[i];
                arr[i]=arr[j];
                arr[j]=temp;
            }
        }
    }
    for(i=0;i<5;i++) printf("%d ", arr[i]);
    return 0;
}
```"""

    if "c even or odd" in user_input:
        return """```c
#include <stdio.h>
int main() {
    int n;
    printf("Enter number: ");
    scanf("%d", &n);
    if(n%2==0) printf("Even");
    else printf("Odd");
    return 0;
}
```"""

    if "c reverse array" in user_input:
        return """```c
#include <stdio.h>
int main() {
    int arr[5]={1,2,3,4,5}, i;
    for(i=4;i>=0;i--) {
        printf("%d ", arr[i]);
    }
    return 0;
}
```"""

    if "c count even odd" in user_input:
        return """```c
#include <stdio.h>
int main() {
    int start=1,end=10, even=0, odd=0;
    for(int i=start;i<=end;i++) {
        if(i%2==0) even++;
        else odd++;
    }
    printf("Even=%d Odd=%d", even, odd);
    return 0;
}
```"""

    if "c vowels consonants" in user_input:
        return """```c
#include <stdio.h>
#include <string.h>
int main() {
    char str[100];
    int v=0,c=0;
    printf("Enter string: ");
    gets(str);
    for(int i=0;i<strlen(str);i++) {
        char ch=tolower(str[i]);
        if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u') v++;
        else if(ch>='a' && ch<='z') c++;
    }
    printf("Vowels=%d Consonants=%d Total=%d", v, c, v+c);
    return 0;
}
```"""

    if "c print numbers" in user_input:
        return """```c
#include <stdio.h>
int main() {
    for(int i=1;i<=5;i++) printf("%d ", i);
    for(int i=1;i<=100;i++) printf("%d ", i);
    printf("Even numbers: ");
    for(int i=2;i<=20;i+=2) printf("%d ", i);
    printf("Odd numbers: ");
    for(int i=1;i<=20;i+=2) printf("%d ", i);
    return 0;
}
```"""

    if "c patterns" in user_input:
        return """```c
#include <stdio.h>
int main() {
    for(int i=1;i<=5;i++) {
        for(int j=1;j<=i;j++) {
            printf("* ");
        }
        printf("\\n");
    }
    return 0;
}
```"""

    if "c calculator" in user_input:
        return """```c
#include <stdio.h>
int main() {
    char op;
    double a,b;
    printf("Enter operator (+,-,*,/): ");
    scanf(" %c", &op);
    printf("Enter two numbers: ");
    scanf("%lf %lf", &a, &b);
    switch(op) {
        case '+': printf("%.2lf", a+b); break;
        case '-': printf("%.2lf", a-b); break;
        case '*': printf("%.2lf", a*b); break;
        case '/': printf("%.2lf", a/b); break;
        default: printf("Invalid operator");
    }
    return 0;
}
```"""

    if "c attendance project" in user_input:
        return """```c
#include <stdio.h>
int main() {
    int total, present;
    printf("Enter total classes: ");
    scanf("%d", &total);
    printf("Enter classes attended: ");
    scanf("%d", &present);
    float percent = (present*100.0)/total;
    printf("Attendance = %.2f%%\\n", percent);
    if(percent < 75) printf("Not eligible for exam");
    else printf("Eligible for exam");
    return 0;
}
```"""

    if "c comments" in user_input:
        return """```c
#include <stdio.h>
int main() {
    // This is single-line comment
    /* This is 
       multi-line comment */
    printf("Comments example in C");
    return 0;
}
```"""

    if "c oops" in user_input or "c methods operators" in user_input:
        return "⚠️ OOP is not directly supported in C. You can implement it using structures + function pointers, but better use C++ for OOP."



    # =========================
    # General C++ Program Codes
    # =========================
    if "c++ factorial" in user_input:
        return """```cpp
#include <iostream>
using namespace std;
int main() {
    int n, fact = 1;
    cout << "Enter number: ";
    cin >> n;
    for(int i=1; i<=n; i++) fact *= i;
    cout << "Factorial: " << fact;
    return 0;
}
```"""

    if "c++ fibonacci" in user_input:
        return """```cpp
#include <iostream>
using namespace std;
int main() {
    int n, t1=0, t2=1, nextTerm;
    cout << "Enter terms: ";
    cin >> n;
    cout << "Fibonacci: ";
    for(int i=1; i<=n; i++) {
        cout << t1 << " ";
        nextTerm = t1 + t2;
        t1 = t2;
        t2 = nextTerm;
    }
    return 0;
}
```"""

    if "c++ palindrome" in user_input:
        return """```cpp
#include <iostream>
using namespace std;
int main() {
    int n, r, sum=0, temp;
    cout << "Enter number: ";
    cin >> n;
    temp = n;
    while(n>0) {
        r = n % 10;
        sum = sum*10 + r;
        n /= 10;
    }
    if(temp == sum) cout << "Palindrome";
    else cout << "Not Palindrome";
    return 0;
}
```"""

    if "c++ prime" in user_input:
        return """```cpp
#include <iostream>
using namespace std;
int main() {
    int n, flag=0;
    cout << "Enter number: ";
    cin >> n;
    for(int i=2;i<=n/2;i++){
        if(n%i==0){ flag=1; break; }
    }
    if(flag==0) cout << "Prime";
    else cout << "Not Prime";
    return 0;
}
```"""

    if "c++ string reverse" in user_input:
        return """```cpp
#include <iostream>
#include <algorithm>
using namespace std;
int main() {
    string s;
    cout << "Enter string: ";
    cin >> s;
    reverse(s.begin(), s.end());
    cout << "Reversed: " << s;
    return 0;
}
```"""

    if "c++ swap" in user_input:
        return """```cpp
#include <iostream>
using namespace std;
int main() {
    int a=5, b=10;
    cout << "Before swap: " << a << " " << b << endl;
    int temp=a; a=b; b=temp;
    cout << "After swap: " << a << " " << b;
    return 0;
}
```"""

    if "c++ sort" in user_input:
        return """```cpp
#include <iostream>
#include <algorithm>
using namespace std;
int main() {
    int arr[] = {5,2,8,1,3};
    int n = 5;
    sort(arr, arr+n);
    cout << "Sorted: ";
    for(int i=0;i<n;i++) cout << arr[i] << " ";
    return 0;
}
```"""

    if "c++ even or odd" in user_input:
        return """```cpp
#include <iostream>
using namespace std;
int main() {
    int n;
    cout << "Enter number: ";
    cin >> n;
    if(n%2==0) cout << "Even";
    else cout << "Odd";
    return 0;
}
```"""

    if "c++ reverse array" in user_input:
        return """```cpp
#include <iostream>
using namespace std;
int main() {
    int arr[]={1,2,3,4,5};
    int n=5;
    cout<<"Reversed array: ";
    for(int i=n-1;i>=0;i--) cout<<arr[i]<<" ";
    return 0;
}
```"""

    if "c++ count even odd between" in user_input:
        return """```cpp
#include <iostream>
using namespace std;
int main() {
    int n, even=0, odd=0;
    cout<<"Enter range: ";
    cin>>n;
    for(int i=1;i<=n;i++){
        if(i%2==0) even++;
        else odd++;
    }
    cout<<"Even: "<<even<<" Odd: "<<odd;
    return 0;
}
```"""

    if "c++ vowels consonants" in user_input:
        return """```cpp
#include <iostream>
using namespace std;
int main() {
    string s;
    int v=0,c=0;
    cout<<"Enter string: ";
    cin>>s;
    for(char ch:s){
        if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u'||
           ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U') v++;
        else c++;
    }
    cout<<"Vowels: "<<v<<" Consonants: "<<c<<" Total: "<<s.size();
    return 0;
}
```"""

    if "c++ print numbers" in user_input:
        return """```cpp
#include <iostream>
using namespace std;
int main() {
    for(int i=1;i<=5;i++) cout<<i<<" ";
    cout<<"\\nEven upto 100: ";
    for(int i=2;i<=100;i+=2) cout<<i<<" ";
    cout<<"\\nOdd upto 100: ";
    for(int i=1;i<=100;i+=2) cout<<i<<" ";
    return 0;
}
```"""

    if "c++ pattern" in user_input:
        return """```cpp
#include <iostream>
using namespace std;
int main() {
    int n=5;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=i;j++) cout<<"*";
        cout<<"\\n";
    }
    return 0;
}
```"""

    if "c++ if example" in user_input:
        return """```cpp
#include <iostream>
using namespace std;
int main() {
    int n=10;
    if(n>0) cout<<"Positive";
    else if(n<0) cout<<"Negative";
    else cout<<"Zero";
    return 0;
}
```"""

    if "c++ for loop example" in user_input:
        return """```cpp
#include <iostream>
using namespace std;
int main() {
    for(int i=1;i<=10;i++) cout<<i<<" ";
    return 0;
}
```"""

    if "c++ nested loop" in user_input:
        return """```cpp
#include <iostream>
using namespace std;
int main() {
    for(int i=1;i<=3;i++){
        for(int j=1;j<=3;j++) cout<<"("<<i<<","<<j<<") ";
        cout<<"\\n";
    }
    return 0;
}
```"""

    if "c++ calculator" in user_input:
        return """```cpp
#include <iostream>
using namespace std;
int main() {
    char op; float a,b;
    cout<<"Enter operator (+,-,*,/): "; cin>>op;
    cout<<"Enter two numbers: "; cin>>a>>b;
    switch(op){
        case '+': cout<<a+b; break;
        case '-': cout<<a-b; break;
        case '*': cout<<a*b; break;
        case '/': cout<<a/b; break;
        default: cout<<"Invalid";
    }
    return 0;
}
```"""

    if "c++ attendance project" in user_input:
        return """```cpp
#include <iostream>
#include <map>
using namespace std;
int main() {
    map<string,bool> attendance;
    attendance["Alice"]=true;
    attendance["Bob"]=false;
    attendance["Charlie"]=true;
    for(auto p:attendance){
        cout<<p.first<<" : "<<(p.second?"Present":"Absent")<<"\\n";
    }
    return 0;
}
```"""

    if "c++ oops example" in user_input:
        return """```cpp
#include <iostream>
using namespace std;
class Student {
public:
    string name;
    int age;
    void display() {
        cout<<"Name: "<<name<<" Age: "<<age;
    }
};
int main() {
    Student s;
    s.name="John"; s.age=20;
    s.display();
    return 0;
}
```"""

    if "c++ comments" in user_input:
        return """```cpp
#include <iostream>
using namespace std;
int main() {
    // This is single line comment
    /* This is multi-line 
       comment */
    cout<<"Hello C++";
    return 0;
}
```"""

    if "c++ operators" in user_input:
        return """```cpp
#include <iostream>
using namespace std;
int main() {
    int a=10,b=3;
    cout<<"Sum: "<<a+b<<" Diff: "<<a-b<<" Prod: "<<a*b<<" Div: "<<a/b;
    return 0;
}
```"""
# Quiz based suggestions

    if "score" in user_input:

        try:
            score = int(user_input.split()[-1])

            if score < 5:
                return "You should focus on Basics: variables, loops, and conditions."

            elif score < 10:
                return "You understand basics but improve Coding & Logic building."

            else:
                return "Great work! Try solving more complex problems."

        except:
            pass
    # ---------------------------
    # Smart Concept Detection
    # ---------------------------

    concepts = {
        "loop": "A loop repeats a block of code multiple times until a condition becomes false.",
        "array": "An array is a collection of elements of the same data type stored in contiguous memory locations.",
        "function": "A function is a reusable block of code that performs a specific task.",
        "recursion": "Recursion is when a function calls itself to solve smaller parts of a problem.",
        "class": "A class is a blueprint used to create objects in object-oriented programming.",
        "object": "An object is an instance of a class containing data and methods.",
        "inheritance": "Inheritance allows one class to acquire the properties and behavior of another class.",
        "polymorphism": "Polymorphism allows methods to perform different tasks depending on the object calling them.",
        "encapsulation": "Encapsulation hides internal data and allows controlled access through methods.",
        "abstraction": "Abstraction hides implementation details and exposes only essential features.",
        "algorithm": "An algorithm is a step-by-step procedure used to solve a problem.",
        "data structure": "A data structure is a way of organizing and storing data efficiently.",
        "stack": "A stack is a data structure that follows LIFO (Last In First Out).",
        "queue": "A queue is a data structure that follows FIFO (First In First Out).",
        "linked list": "A linked list is a data structure where elements are connected using pointers.",
        "pointer": "A pointer is a variable that stores the memory address of another variable.",
        "variable": "A variable is a named memory location used to store data.",
        "constant": "A constant is a value that cannot change during program execution.",
        "compiler": "A compiler converts high-level programming code into machine code.",
        "interpreter": "An interpreter executes code line by line without compiling the entire program first."
    }

    for concept, explanation in concepts.items():
        if concept in user_input:
            return explanation
    if "practice problems" in user_input:
        return """Try solving these beginner problems:

1. Print numbers from 1 to 100
2. Check if number is prime
3. Reverse a string
4. Find factorial of a number
5. Count vowels in a string
"""

    if "coding challenge" in user_input:
        return """Coding Challenge 🔥

    Write a program to:

    Input: 12345
    Output: 54321

Try reversing a number using loops."""
    if "how to learn programming" in user_input:
        return """Best way to learn programming:

    Step 1 → Learn basics (variables, loops, conditions)  
    Step 2 → Practice small programs  
    Step 3 → Learn functions and data structures  
    Step 4 → Solve coding problems  
    Step 5 → Build projects  

    Consistency is key 🚀"""
    if "programming roadmap" in user_input:
        return """Programming Learning Roadmap:

    1️⃣ Basics  
    Variables, loops, conditions  

    2️⃣ Intermediate  
    Functions, arrays, strings  

    3️⃣ Advanced  
    OOP, data structures  

    4️⃣ Expert  
    Algorithms, system design  

    Practice daily 🚀"""
    if "quiz help" in user_input:
        return """Based on your quiz performance:

Score < 5  
Focus on:
• Variables
• Loops
• Conditions

Score 5-10  
Improve:
• Problem solving
• Coding logic

Score > 10  
Great! Start learning:
• Data structures
• Algorithms
• Advanced coding
"""
# ---------------------------
# Topic Detection
# ---------------------------

    if "python" in user_input:
        return "You are asking about Python 🐍. Try asking about loops, lists, functions, or classes."

    if "java" in user_input:
        return "You are asking about Java ☕. Try asking about inheritance, interfaces, or OOP concepts."

    if "c++" in user_input:
        return "You are asking about C++ 💻. You can ask about classes, constructors, STL, or polymorphism."

    if "c language" in user_input or "c programming" in user_input:
        return "You are asking about C 🔵. Try asking about pointers, arrays, structures, or memory allocation."

    # =========================
    # Default
    # =========================
    return f"🤔 I got your question: '{user_input}'. I don't have a direct answer yet, but I'm learning!"

