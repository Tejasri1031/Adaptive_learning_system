from flask import Flask, render_template, request, redirect, url_for, session, jsonify, send_from_directory
import os, json
from chat_responses import get_response

app = Flask(__name__)
app.secret_key = "adaptive_ai_secret_key"


# ==============================
# HOME PAGE
# ==============================
@app.route("/")
def home():
    return render_template("home.html")


# ==============================
# LOGIN PAGE
# ==============================
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")

        if not username:
            return render_template("login.html", error="Username required")

        session["user"] = username
        return redirect(url_for("dashboard"))

    return render_template("login.html")


# ==============================
# REGISTER PAGE (you have register.html)
# ==============================
@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":
        name = request.form.get("name")
        username = request.form.get("username")
        password = request.form.get("password")

        if not name or not username or not password:
            return render_template("register.html", error="All fields are required")

        # For now (debug)
        print("User Registered:", name, username, password)

        return redirect(url_for("login"))

    return render_template("register.html")

# ==============================
# DASHBOARD
# ==============================
@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        return redirect(url_for("login"))

    return render_template("dashboard.html", user=session["user"])


# ==============================
# COURSES PAGE
# ==============================
@app.route("/courses")
def course_page():
    if "user" not in session:
        return redirect(url_for("login"))

    return render_template("courses.html")

# ==============================
# COURSE LESSON PAGES
# ==============================
@app.route("/courses/<course>/<lesson>")
def course_lesson(course, lesson):
    if "user" not in session:
        return redirect(url_for("login"))

    try:
        return render_template(f"courses/{course}/{lesson}")
    except:
        return "Lesson not found", 404


# ==============================
# LESSONS PAGE
# ==============================
@app.route("/lessons")
def lessons():
    if "user" not in session:
        return redirect(url_for("login"))

    return render_template("lessons.html")


# ==============================
# INTERNSHIP PAGE
# ==============================
@app.route("/internship")
def internship():
    if "user" not in session:
        return redirect(url_for("login"))

    return render_template("internship.html")


# ==============================
# MISSIONS PAGE
# ==============================
@app.route("/missions")
def missions():
    if "user" not in session:
        return redirect(url_for("login"))

    return render_template("missions.html")


# ==============================
# MISSION MODES PAGE
# ==============================
@app.route("/mission-modes/<subject>")
def mission_modes(subject):
    if "user" not in session:
        return redirect(url_for("login"))

    subject = subject.lower()
    allowed = ["python", "java", "html", "c"]

    if subject not in allowed:
        return "Invalid Subject", 404

    return render_template("mission_modes.html", subject=subject)


# ==================================
# GAMIFIED LEARNING MAIN PAGE
# ==================================

@app.route("/gamified-learning")
def gamified_learning():

    if "user" not in session:
        return redirect(url_for("login"))

    subjects = ["python", "java", "cpp", "c"]

    return render_template(
        "gamified_learning.html",
        subjects=subjects
    )


# ==================================
# DIFFICULTY MODE PAGE
# ==================================

@app.route("/gamified-modes/<subject>")
def gamified_modes(subject):

    if "user" not in session:
        return redirect(url_for("login"))

    modes = ["easy", "moderate", "hard"]

    return render_template(
        "mission_modes.html",
        subject=subject,
        modes=modes
    )


# ==================================
# MISSION LEVEL PAGE
# ==================================

@app.route("/mission-level/<subject>/<mode>/<int:level>")
def mission_level(subject, mode, level):

    file_path = os.path.join(
        app.root_path,
        "models",
        "gamified_questions",
        subject.lower(),
        f"{mode.lower()}.json"
    )

    with open(file_path) as f:
        data = json.load(f)

    subject_key = subject.capitalize()
    mode_key = mode.capitalize()
    level_key = f"Level{level}"

    questions = data.get(subject_key, {}).get(mode_key, {}).get(level_key, [])

    return render_template(
        "mission_levels.html",
        subject=subject,
        mode=mode,
        level=level,
        questions=questions
    )

# ==================================
# SUBMIT MISSION
# ==================================

@app.route("/submit-mission/<subject>/<mode>/<int:level>", methods=["POST"])
def submit_mission(subject, mode, level):

    subject = subject.lower()
    mode = mode.lower()

    file_path = os.path.join(
        app.root_path,
        "models",
        "gamified_questions",
        subject,
        f"{mode}.json"
    )

    score = 0
    correct = 0
    wrong = 0

    try:

        with open(file_path) as f:
            questions = json.load(f)

        for i, q in enumerate(questions):

            user_answer = request.form.get(f"q_{i}")

            if user_answer == q["answer"]:
                score += 3
                correct += 1

            elif user_answer is None:
                pass

            else:
                score -= 1
                wrong += 1

    except Exception as e:
        print("Submission error:", e)

    # XP calculation
    xp = correct * 10

    # Decide next difficulty
    if mode == "easy":
        next_mode = "moderate"
    elif mode == "moderate":
        next_mode = "hard"
    else:
        next_mode = None

    return render_template(
    "mission_result.html",
    score=score,
    xp=xp,
    correct=correct,
    wrong=wrong,
    subject=subject,
    mode=mode,
    level=level
)

# realtime apps 
@app.route("/realtime")
def realtime():
    return render_template("realtime.html")

@app.route("/realtime-data")
def realtime_data():
    with open("realtime.json") as f:
        data = json.load(f)
    return jsonify(data)

# ==============================
# QUIZ SELECTION PAGE
# ==============================
@app.route("/quiz-select")
def quiz_select():

    if "user" not in session:
        return redirect(url_for("login"))

    return render_template("quiz_select.html")


# ==============================
# QUIZ PAGE
# ==============================
@app.route("/quiz/<subject>")
def quiz(subject):

    if "user" not in session:
        return redirect(url_for("login"))

    subject = subject.lower()

    allowed_subjects = ["python", "java", "c", "cpp"]

    if subject not in allowed_subjects:
        return "Invalid Subject", 404

    return render_template("quiz.html", subject=subject)


# ==============================
# START QUIZ
# ==============================
@app.route("/start_quiz", methods=["POST"])
def start_quiz():

    subject = request.form.get("subject")

    if not subject:
        return redirect(url_for("quiz_select"))

    return redirect(url_for("quiz", subject=subject.lower()))


# ==============================
# RESULT PAGE
# ==============================
@app.route("/result")
def result():

    if "user" not in session:
        return redirect(url_for("login"))

    return render_template("result.html")
  
# ===============================
# QUIZ PAGE (Dynamic Template)
# ===============================
@app.route("/quiz/<course>/<topic>")
def quiz_page(course, topic):

    course = course.lower()
    topic = topic.lower()

    return render_template(
        "courses/quiz.html",
        course=course,
        topic=topic
    )

# ===============================
# SERVE QUIZ JSON FILES
# ===============================
@app.route("/questions/<course>_quiz/<path:filename>")
def serve_questions(course, filename):

    folder_map = {
        "python": "questions/python_quiz",
        "java": "questions/java_quiz",
        "c": "questions/c_quiz",
        "cpp": "questions/cpp_quiz"
    }

    folder = folder_map.get(course.lower())

    if not folder:
        return "Invalid course", 404

    folder_path = os.path.join(app.root_path, folder)

    return send_from_directory(folder_path, filename)

# ==============================
# FEEDBACK PAGE
# ==============================
@app.route("/feedback", methods=["GET","POST"])
def feedback():

    questions = [
        "What did you learn?",
        "What was difficult?",
        "What should we improve?"
    ]

    if request.method == "POST":

        answers = []
        for i in range(len(questions)):
            ans = request.form.get(f"q{i}", "")
            answers.append(ans)

        feedback_text = " | ".join(answers)

        with open("feedback.txt", "a") as f:
            f.write(feedback_text + "\n")

        return render_template(
            "feedback.html",
            done=True,
            result="Your feedback helps improve the course!"
        )

    return render_template("feedback.html", questions=questions, done=False)
# ==============================
# CHATBUDDY PAGE
# ==============================
from chat_responses import get_response
from flask import request, jsonify

@app.route("/chatbuddy")
def chatbuddy():
    return render_template("chatbuddy.html")


@app.route("/chatbot", methods=["POST"])
def chatbot():

    user_message = request.json.get("message")

    reply = get_response(user_message)

    return jsonify({"reply": reply})

# ==============================
# APPLICATIONS PAGE
# ==============================
@app.route("/applications")
def applications():
    if "user" not in session:
        return redirect(url_for("login"))

    return render_template("applications.html")


# ==============================
# LOGOUT
# ==============================
@app.route("/logout")
def logout():
    session.pop("user", None)
    return redirect(url_for("home"))


# ==============================
# RUN SERVER
# ==============================
if __name__ == "__main__":
    app.run(debug=True)