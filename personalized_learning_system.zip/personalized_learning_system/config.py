import os

# Flask secret key
SECRET_KEY = os.environ.get("SECRET_KEY", "mysecretkey123")

# MongoDB URI
MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017/adaptive_learning")

# OpenAI API Key for GPT chatbot (only if you're using it)
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "your-openai-api-key")
